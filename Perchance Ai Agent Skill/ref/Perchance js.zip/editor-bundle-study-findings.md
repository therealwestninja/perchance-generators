# Editor-bundle study: Companion improvements

Three library files were studied, all of them Perchance's *own* shipped code, so
these are ground truth rather than inference:

- `editors_bundle_min.js` (862 KB) — the Perchance editor shell (CodeMirror 6 +
  the lint/collab/copilot wiring).
- `eslint-linter-browserify-v9.14.0-bundle.mjs` — the esm.sh browser build of
  ESLint 9.14.0. **This is the exact lib the editor lazy-imports.**
- `htmlparser2-v9.1.0-bundle.mjs` — the esm.sh browser build of htmlparser2 9.1.0.
  **Also the exact lib the editor lazy-imports.**

The headline: Perchance lints both editor panes with ESLint, locating the JS
inside the HTML pane with htmlparser2; it runs a realtime collab layer on Yjs;
and its bug-finder / autocomplete are calls to `editor-copilot.perchance.org`.
All three are reachable or replicable from the Companion. Findings are ordered by
value to the userscript.

---

## A. The lint pipeline → a pre-save / pre-Push lint gate ★ highest value

### A1. How Perchance lints (exact wiring)
On demand the editor does:

```js
await Promise.all([
  import(window.eslintImportUrl     || "https://perchance.org/lib/eslint-linter-browserify-v9.14.0-bundle.mjs"),
  import(window.htmlparser2ImportUrl|| "https://perchance.org/lib/htmlparser2-v9.1.0-bundle.mjs"),
]);
window.htmlparser2 = <htmlparser2 module>;
window.eslintInstances = {};
for (let t of ["modelText", "outputTemplate"])
  window.eslintInstances[t] = new <eslint>.Linter();   // one Linter per pane
```

So there are **two persistent `window.eslintInstances`** — `modelText` and
`outputTemplate` — and **`window.htmlparser2`** is exposed globally once loaded.

For the HTML pane, `extractJavaScriptRegionsFromHtml(docString)` runs
`new htmlparser2.Parser({ onopentag(name){ if (name==="script") … } })` to find
each `<script>` block's byte range and `scriptType` (module vs classic), then
lints only those JS regions. The model-text pane is linted as JS directly.

The verify config is deliberately minimal:

```js
{ languageOptions: { globals: {}, parserOptions: { ecmaVersion: 2022, sourceType: "module"|"script" } },
  rules: {} }
```

`rules:{}` + `globals:{}` means **this is syntax/parse checking only** — it flags
genuinely broken JS (unclosed brackets, bad tokens, illegal returns) and nothing
stylistic. `sourceType` is `"module"` when the `<script type=module>`, else
`"script"`. Each diagnostic is mapped to `{ message, source: "eslint:"+ruleId,
severity: sev===1?"warning":"error" }`, and when ESLint returns `e.fix`
(`{range:[from,to], text}`) it becomes a one-click autofix in the gutter.

### A2. What the Companion should build
A **pre-action lint gate** — the thing `node --check` (which only validates the
userscript itself) and the Companion currently can't see:

- **Before Save** and **before Push**: lint both panes; if there are errors, show
  "N errors / M warnings — Save/Push anyway?" with the first few messages +
  line numbers. Stops broken JS from being committed to GitHub or saved live.
- **After Pull** (before writing into the pane, or right after): lint the fetched
  content so a bad pull is caught immediately instead of at next Save.

Implementation, zero-redundancy and evidence-driven:
1. **Prefer Perchance's already-loaded instances.** If `window.eslintInstances`
   and `window.htmlparser2` exist (they will, once the user has triggered lint
   once), reuse them — no second download, identical behaviour to the gutter.
2. **Fallback `@require`** the two bundles Davie supplied (same versions/URLs) and
   build our own `new Linter()` + `htmlparser2.Parser` when the globals aren't up
   yet. Mirror `extractJavaScriptRegionsFromHtml` for the HTML pane (htmlparser2
   `onopentag`/`startIndex`/`endIndex` over the doc string) and verify each region
   with `{parserOptions:{ecmaVersion:2022, sourceType}}`, `rules:{}`.
3. Render the consolidated problem list in the Companion (we already have the
   diagnostic shape and severity mapping). Optionally expose the autofix.

Cost: medium. Risk: low (read-only analysis; reuses Perchance's own libs/config).
This is the strongest single win in the three bundles.

---

## B. The collab system → a creds-free "Collaborate" panel ★ high value

Full lifecycle now confirmed from the bundle (consumption side was already mapped
from `bug-report-plugin_html.txt`).

### B1. Endpoints (owner-authed unless noted)
- `GET /api/getCollabEditKey?generatorName=&sessionToken=&email=[&editKey=]` →
  `{ key }`. Mints (or fetches) the collab key.
- `POST /api/regenerateCollabEditKey` body `{generatorName, sessionToken, email}` —
  rotates the key; **invalidates the existing link**.
- `POST /api/deleteCollabEditKey` — revokes collab entirely.
- `GET /api/validateCollabEditKey?generatorName=&key=` → `{status:"invalid"}` when
  bad. **No auth** — this is the collaborator-side heartbeat (every 30 s; on
  invalid it calls `window.yjsProvider.disconnect()` and the next save nulls the
  key and offers "save your own copy").

### B2. Link assembly + realtime
- Link is built client-side as
  `` `${location.origin}${location.pathname}#edit:collab=${key}` `` into
  `editorCollabLinkEl.value`.
- Realtime is **Yjs**:
  `window.yjsProvider = new WebsocketProvider("wss://editor-collab.perchance.org",
  room, window.yDoc, { awareness: window.yjsAwareness, maxBackoffTime: 1e4,
  params: { clientProtocol: "2" } })`. Panes are `window.yDoc.getText(docId)`
  Y.Text; editor is read-only until initial sync
  (`editorCollabInitialSyncIsPending` via `getCollabEditabilityExtensions` =
  `EditorState.readOnly.of(e)` + `EditorView.editable.of(!e)`). A collab link is
  live co-editing, not just shared save.

### B3. The editor's own collab UI elements (drive these, don't re-auth)
`collabLink` toolbar button (title: "Generate a collaboration link to share with
others so you can work together in realtime."), `collabLinkContentEl`,
`editorCollabLinkEl` (holds the link), `copyEditorCollabLinkBtn` ("📋 copy" →
"✅ copied!"), `collabEnableDisableSelectEl` (enabled/disabled),
`regenerateEditorCollabLinkBtn`. Regenerate confirms: "This will invalidate the
existing collab link, meaning that anyone with the existing [link]…". Share note:
"If you share your collab link with someone, they'll be able to **edit**/**save**".

### B4. What the Companion should build
A **Collaborate** control in the per-generator actions row that **drives
Perchance's own collab UI** — click `collabLink` to open it, read
`editorCollabLinkEl.value` to copy, click `regenerateEditorCollabLinkBtn` to
rotate, trigger delete to revoke — exactly the creds-free pattern already used for
rename/delete. The Companion never handles `sessionToken`. Pair it with a one-line
security note ("anyone with this link can edit + save until you regenerate or
delete it; it lives in the URL — treat it like a shared password").

Cost: low–medium (DOM driving + a small panel). Risk: low (uses Perchance's UI).
Needs a quick live probe to confirm the element IDs are present on the page and
that `collabLink` opens the panel without an edit-password prompt for an owner.

---

## C. editor-copilot endpoints → an AI bug-check button ◐ medium value

Both are `POST https://editor-copilot.perchance.org/api/…`, JSON body, and notably
**carry no sessionToken/email** (only `generatorName` + content):

- `…/api/findBugsInCode` body `{ code, contentType, generatorName }`. `contentType`
  is the pane's docId (`"modelText"` / `"outputTemplate"`). Server-side AI bug
  review.
- `…/api/autocomplete` body `{ prefix, suffix, contentType, generatorName }` —
  inline code completion.

### What the Companion could build
A **"Find bugs (AI)"** button that posts the current pane's text to
`findBugsInCode` and shows the result in the Companion — creds-free, one call,
cheap to add (we already do all network via `GM_xmlhttpRequest`; add
`editor-copilot.perchance.org` to `@connect`). Autocomplete is a deeper editor
integration — defer. Caveat: copilot may be rate-limited/quota'd server-side;
treat failures gracefully.

---

## D. Save reachability (note, not yet a change)
The real save is `this.saveGenerator = async () => {…}` on the app component.
`window.app` is exposed (`window.app.store.data.user.{sessionToken,email,loggedIn}`
are all read off it), but `saveGenerator` was **not** confirmed as
`window.app.saveGenerator` directly — it's defined inside the component closure.
The Companion's synthetic Ctrl/Cmd+S (which triggers the document-level binding)
remains the right approach. **Probe to try:** does `window.app.saveGenerator` (or
`window.app.<child>.saveGenerator`) exist and call cleanly? If so, the Companion
could invoke save directly and read the returned promise instead of polling
`perchanceSaveState`. Low priority — current path works.

---

## E. Override hooks worth knowing
`window.eslintImportUrl` and `window.htmlparser2ImportUrl` let the page override
where the editor pulls its lint libs from. Out of scope for the Companion (no
reason to repoint Perchance's own lint), but documents that both are intentional,
swappable globals — and confirms the Companion may safely read/reuse
`window.eslintInstances` / `window.htmlparser2` once present.

---

## Ranked recommendation
1. **Pre-save / pre-Push lint gate** (A) — biggest, uses the supplied libs,
   prevents shipping broken JS. Reuse `window.eslintInstances`/`window.htmlparser2`
   with an `@require` fallback.
2. **Collaborate panel** (B) — drive Perchance's own collab UI, creds-free; closes
   the loop on the collab investigation.
3. **AI bug-check button** (C) — small, creds-free, genuinely useful.
4. **Direct-save probe** (D) — only if a live probe shows `saveGenerator` is
   reachable.

Open probes before building: confirm `window.eslintInstances` is populated on a
normal edit page (or whether we must import ourselves first); confirm the collab
element IDs render for an owner and that `collabLink` opens without prompting.
